#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"
#include "utils/uartstdio.h"


unsigned int guiValue[8];		// 2개의 좌표를 기억할 변수 지정
unsigned int guiVol;
unsigned int guiVolInt, guiVolDeci;


void UARTInit()
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);	//UART0을 사용 가능한 상태로 설정
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);	//GPIOA를 사용 가능한 상태로 설정
	GPIOPinConfigure(GPIO_PA0_U0RX);		//GPIO A0 핀을 UART0 의 Rx로 사용하도록 설정
	GPIOPinConfigure(GPIO_PA1_U0TX);		//GPIO A1 핀을 UART0의 Tx로 사용하도록 설정
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);// GPIO A0, A1을 UART로 사용하도록 설정
	UARTStdioConfig(0, 115200, 120000000 );	//UART0 을 현재클럭(120Mhz)을 이용하여 115200bps로 설정
}

void Display(void)
{
	UARTprintf("\033[2J\033[H");
	UARTprintf("ADCValue(압력센서): %u\n", guiValue[0]);  // 캡쳐된 데이터 값
}

// 시퀀스 0번의 인터럽트 서비스 루틴(데이터 변환이 완료되었을 시 실행)
void ADCSeq0Handler(void)
{
	ADCSequenceDataGet(ADC0_BASE, 0, guiValue);
	Display();
	ADCIntClear(ADC0_BASE, 0);		// ADC 인터럽트 클리어
}


void main(void)
{
	//동작 클럭을  120Mhz로 설정(크리스탈 클럭 25Mhz | 메인 오실레이터 | 오실레이터 클럭을 사용  | PLL사용 | PLL 클럭 480Mhz | 생성 클럭을 120Mhz로 설정)
	SysCtlClockFreqSet(SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480, 120000000);

	UARTInit(); //UART초기화

	SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0); // ADC 사용
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);  // GPIO K 사용

	GPIOPinTypeADC(GPIO_PORTK_BASE, GPIO_PIN_3); // K3 핀을 ADC로 설정

	// 프로세서에서 트리거 신호가 발생되면 채널 0번의 값을 캡쳐하기위해
	// 샘플 시퀀스 0번을 Enable시킴
	ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);

	// 샘플 시퀀스00번이 port K2(AIN18)의 데이터를 변환 완료하면 인터럽트 발생
	// 변환된 데이터는 FIFO 0에 저장
	ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH19 | ADC_CTL_IE | ADC_CTL_END);

	// 샘플 시퀀스  Enable
	ADCSequenceEnable(ADC0_BASE, 0);

	// ADC0을  내부 클럭 16Mhz를 이용하여 설정
	ADCClockConfigSet(ADC0_BASE, ADC_CLOCK_SRC_PIOSC | ADC_CLOCK_RATE_FULL, 0);

	// 프로세서 인터럽트 Enable
	IntMasterEnable();

	// Enable ADC 샘플 시퀀스 인터럽트 Enable
	ADCIntEnable(ADC0_BASE, 0);

	IntEnable(INT_ADC0SS0); // Enable interrupt of Sample Sequencer 0

    while(1)
    {
       	ADCProcessorTrigger(ADC0_BASE, 0);	//ADC soft trigger

    	SysCtlDelay(12000000 /3/2);   // about 500ms delay which says 3 seconds delay at 120MHz SysClk since it takes 3 clocks
    }
}
