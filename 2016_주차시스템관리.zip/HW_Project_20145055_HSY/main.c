//LED랑 모터랑 압력센서
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

unsigned int guiValue[8]; //압력센서 값을 받을 변수
unsigned long ulPeriod;	  // 시스템 클럭 변수
void
Delay(uint32_t ui32Seconds) //딜레이 함수
{
    uint8_t ui8Loop;

    //
    // Loop while there are more seconds to wait.
    //
    while(ui32Seconds--)
    {
        for(ui8Loop = 0; ui8Loop < 100; ui8Loop++)
        {
            //
            // Wait until the SysTick value is less than 1000.
            //
            while(SysTickValueGet() > 1000)
            {
            }

            //
            // Wait until the SysTick value is greater than 1000.
            //
            while(SysTickValueGet() < 1000)
            {
            }
        }
    }

}

void
IntGPIOA(void)//푸쉬버튼이 눌렸을 때 실행되는 인터럽트
{
	//만약 압력센서가 눌린다면 주차할 공간이 없으므로 서보모터를 올리지 않음
	if(guiValue[0]<3000){
		//서보 모터 주기 설정
		PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, ulPeriod);
		//서보모터 dyty ratio를 7%로 설정 => 약 0도
		PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ulPeriod/13);
	}
	//버튼 인터럽트 클리어
	GPIOIntClear(GPIO_PORTA_BASE, GPIO_PIN_0);
	//안전바가 1초 있다가 내려가라고 Delay를 줌
	Delay(1);
}

void ADCSeq0Handler(void)// 시퀀스 0번의 인터럽트 서비스 루틴(데이터 변환이 완료되었을 시 실행)
{
	//ADC로 받은 데이터를 guiValue에 저장
	ADCSequenceDataGet(ADC0_BASE, 0, guiValue);
	//압력센서가 눌리면 빨간LED를 켜서 주차가 되었다고 알림. 노란 LED는 끔
	if(guiValue[0]>3000){
		GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_4, 0x00);
		GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_5, GPIO_PIN_5);
	}
	//압력센서가 눌리지 않았다면 노란 LED를 키고 빨간 LED를 끔
	else{
		GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_4, GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_5, 0x00);
	}
	// ADC 인터럽트 클리어
	ADCIntClear(ADC0_BASE, 0);
}

void main(void)
{
	//시스템 클럭을 받을 변수
	unsigned int ui32SysClock;

	//동작 클럭을  120Mhz로 설정(크리스탈 클럭 25Mhz | 메인 오실레이터 | 오실레이터 클럭을 사용  | PLL사용 | PLL 클럭 480Mhz | 생성 클럭을 120Mhz로 설정)
	ui32SysClock = SysCtlClockFreqSet(SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_OSC , 120000000);

	//딜레이를 쓰기위한 함수
	SysTickPeriodSet(ui32SysClock / 100);
	SysTickEnable();

	SysCtlPWMClockSet(SYSCTL_PWMDIV_1);	// PWM 분주는 1로 설정

	SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0); // ADC 사용
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);// GPIO K 사용
	SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);	// PWM 기능 사용
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);//GPIO Port F사용
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOM);//LED 사용
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);//Button 사용
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOM))
	{
	}
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA))
	{
	}
	GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_4|GPIO_PIN_5); //LED 사용 하려고 PORTM에 4,5pin사용
	GPIODirModeSet(GPIO_PORTA_BASE, GPIO_PIN_0, GPIO_DIR_MODE_IN); //Button 사용하기 위한 설정
	GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
	GPIOIntTypeSet(GPIO_PORTA_BASE, GPIO_PIN_0, GPIO_FALLING_EDGE ); //Button 하강 엣지로 설정
	GPIOPinConfigure(GPIO_PF0_M0PWM0);		//GPIO Port F0를 PWM0 기능 으로 설정
	GPIOPinTypeADC(GPIO_PORTK_BASE, GPIO_PIN_3); // K3 핀을 ADC로 설정
	GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_0); //PORT F0

	// 프로세서에서 트리거 신호가 발생되면 채널 0번의 값을 캡쳐하기위해
	// 샘플 시퀀스 0번을 Enable시킴
	ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);

	// 샘플 시퀀스00번이 port K3(AIN19)의 데이터를 변환 완료하면 인터럽트 발생
	// 변환된 데이터는 FIFO 0에 저장
	ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH19 | ADC_CTL_IE | ADC_CTL_END);

	// 샘플 시퀀스  Enable
	ADCSequenceEnable(ADC0_BASE, 0);

	// ADC0을  내부 클럭 16Mhz를 이용하여 설정
	ADCClockConfigSet(ADC0_BASE, ADC_CLOCK_SRC_PIOSC | ADC_CLOCK_RATE_FULL, 0);

	//주기를 20ms로 설정
	ulPeriod = ui32SysClock * 0.02;
	//pwm up_down 설정
	PWMGenConfigure(PWM0_BASE, PWM_GEN_0, PWM_GEN_MODE_UP_DOWN | PWM_GEN_MODE_NO_SYNC);
	//주기를 20ms로 설정
	PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, ulPeriod);
	//duty ratio를 3%로 설정 약 -90도
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ulPeriod/33);

	// PWM0을 출력 신호로 enable
	PWMOutputState(PWM0_BASE, PWM_OUT_0_BIT, true);

	// PWM generator enable
	PWMGenEnable(PWM0_BASE, PWM_GEN_0);

	// 프로세서 인터럽트 Enable
	IntMasterEnable();

	// 프로세서 GPIOA 인터럽트 Enable
	IntEnable(INT_GPIOA);
	GPIOIntEnable(GPIO_PORTA_BASE,GPIO_PIN_0);

	// Enable ADC 샘플 시퀀스 인터럽트 Enable
	ADCIntEnable(ADC0_BASE, 0);
	IntEnable(INT_ADC0SS0); // Enable interrupt of Sample Sequencer 0

	//초기에 노란LED 키고 빨간 LED끄고
	GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_4, GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_5, 0x00);

	while(1)
	{
		//안전바의 상태는 인터럽트가 걸리지 않는다면 -90도를 유지
		PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, ulPeriod);
		PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, ulPeriod/33);
		ADCProcessorTrigger(ADC0_BASE, 0);	//ADC soft trigger
		SysCtlDelay(12000000 /3/2);   // about 500ms delay which says 3 seconds delay at 120MHz SysClk since it takes 3 clocks
	}
}
